#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*Saya Muhammad Izzatul Haq mengerjakan UAS Nomor 1 dalam mata kuliah Algoritma Pemgrograman 1 untuk keberkahanNya maka saya tidak melakukan kecurangan seperti yang telah dispesifikasikan. Aamiin.*/
void printer(int n,char arr[][50]);
